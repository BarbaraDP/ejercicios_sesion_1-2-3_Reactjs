
import React from 'react';
import PropTypes from 'prop-types';
import { Contacto } from '../../models/contacto.class'


const ComponenteB = ({Contacto}) => {
    return (
            <div>
                <h4>
                    Nombre: { Contacto.nombre }
                </h4>
                <h4>
                    Apellido: { Contacto.apellido }
                </h4>
                <h4>
                    Email: { Contacto.email }
                </h4>

                <h4>
                    Estado: { Contacto.estado ? 'ONLINE':'OFFLINE'}
                </h4>
                


            </div>
        );
    };



ComponenteB.propTypes = {
    nombre: PropTypes.string,
    apellido: PropTypes.string,
    email: PropTypes.string,
    estado: PropTypes.bool,
    contacto: PropTypes.instanceOf(Contacto),

};


export default ComponenteB;
