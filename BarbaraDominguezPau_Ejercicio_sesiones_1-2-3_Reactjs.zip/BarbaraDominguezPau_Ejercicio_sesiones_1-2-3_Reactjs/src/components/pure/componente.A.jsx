
import React from 'react';
import { Contacto } from '../../models/contacto.class'
import ComponenteB from './componente.B';




const ComponenteA = () => {

    const defaultContacto = new Contacto('Bárbara', 'Domínguez', 'barbarad@gmail.com', false);

    return (
        <div>
            <h2>
                Contacto
            </h2>
            <div>
                <ComponenteB Contacto={defaultContacto}></ComponenteB>
            </div>
        </div>

    );



}

export default ComponenteA;
